
 
package Entity;

import java.awt.image.BufferedImage;
import java.io.File;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Table(name="ImageHandling")
@Entity
public class ImageHandling {
   private int Width;
   private int Height;
   BufferedImage Image;
   File F;

public int getWidth() {
	return Width;
}
public void setWidth(int width) {
	Width = width;
}
public int getHeight() {
	return Height;
}
public void setHeight(int height) {
	Height = height;
}
public BufferedImage getImage() {
	return Image;
}
public void setImage(BufferedImage image) {
	Image = image;
}
public File getF() {
	return F;
}
public void setF(File f) {
	F = f;
}




   
   
   
   
   
   
}
