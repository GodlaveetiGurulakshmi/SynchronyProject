package Service;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Entity.ImageHandling;
import Repository.ImageHandlingRepo;

@Service
public class ImageHandlingService {
	
	@Autowired
	 private ImageHandlingRepo imrRepo;
	
			public ImageHandling getImrData(ImageHandling imrHandlings) {
				
				ImageHandling imrHandling=new ImageHandling();
				imrHandling.setWidth(943);
				imrHandling.setHeight(640);
				imrHandling.setImage(null);
				imrHandling.setF(null);
				imrRepo.save(imrHandling);
				return imrHandling;
			}
			
		 
			
	      public ImageHandling viewImage() {
				
				try {
			File f=	new File("https://apidocs.imgur.com/");
		    BufferedImage bufImr= new BufferedImage(943, 640, BufferedImage.TYPE_INT_ARGB);
		    bufImr  =ImageIO.read(f);
			System.out.println("Reading Complete");
			
			} catch (IOException e) {
					System.out.println("Error:"+e);
					
				}
				return null;
			}
	      
	      
			
	    public ImageHandling deleteImage() {
	    	
				try {

					RenderedImage rImr=null;
				File f=	new File("apidocs.imgur.com/");
				ImageIO.write(rImr, "jpg", f);
				System.out.println("Writing Complete");
					
					
					
				} catch (IOException e) {
					System.out.println("Error:"+e);
					
				} 
				return null;
			}
		
		
		 
	 }
	
	
	


	
   
   
	  
	  
  



