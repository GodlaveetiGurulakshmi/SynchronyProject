package Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Entity.ImageHandling;
import Service.ImageHandlingService;

@RestController
public class ImageHandlingController {
	@Autowired
	 private ImageHandlingService service;
	
	@PostMapping("/createImage")
	public ImageHandling getImrDetails(@RequestBody ImageHandling imrHandling) {
		ImageHandling ImrData=service.getImrData(imrHandling);
		return ImrData;
	}
	
	
	@GetMapping("/viewImage")
	public ImageHandling viewHandling() {
	ImageHandling imrView	=service.viewImage();
		return imrView;
		
	}
	
	
	@DeleteMapping("/deleteImage")
	public ImageHandling deleteHandling() {
	ImageHandling imrDelete	=service.deleteImage();
		return imrDelete;
	}
	
	
	
}
